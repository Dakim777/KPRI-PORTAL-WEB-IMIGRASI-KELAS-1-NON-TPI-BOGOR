<table style="border: 1px solid #000;">
    <thead>
        <tr>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">NO</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">TANGGAL TRANSAKSI</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">NO STRUK</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">NAMA PENERIMA</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">NO RESI</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">JUMLAH PASPOR</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">TOTAL PEMBAYARAN PEMOHON</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">BIAYA KURIR (RESI)</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">BIAYA MODAL PACKAGING</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">HANDLING FEE</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">BIAYA MATERAI</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">BIAYA SURAT KUASA</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">PENDAPATAN</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">FEE PETUGAS</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">PENDAPATAN KOPERASI BERSIH</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">TANGGAL PENGIRIMAN PASPOR</th>
            <th style="font-weight: bold; text-align: center; background-color: #FFA500;">TANGGAL PASPOR DITERIMA</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $paspors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $paspor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $row = $index + 2; ?>
            <tr>
                <td style="text-align: center;"><?php echo e($index + 1); ?></td>
                <td><?php echo e($paspor->tanggal_transaksi ? $paspor->tanggal_transaksi->format('d/m/Y') : ''); ?></td>
                <td style="text-align: center;"><?php echo e($paspor->no_struk); ?></td>
                <td><?php echo e($paspor->nama_penerima); ?></td>
                <td><?php echo e($paspor->no_resi); ?></td>
                <td style="text-align: center;"><?php echo e($paspor->jumlah_paspor); ?></td>
                <td style="text-align: right;"><?php echo e($paspor->total_pembayaran_pemohon); ?></td>
                <td style="text-align: right; <?php echo e(empty($paspor->biaya_kurir) || $paspor->biaya_kurir == 0 ? 'background-color: #FFFF00;' : ''); ?>"><?php echo e($paspor->biaya_kurir ?? 0); ?></td>
                <td style="text-align: right; <?php echo e(empty($paspor->biaya_modal_packaging) || $paspor->biaya_modal_packaging == 0 ? 'background-color: #FFFF00;' : ''); ?>"><?php echo e($paspor->biaya_modal_packaging ?? 0); ?></td>
                <td style="text-align: right; <?php echo e(empty($paspor->handling_fee) || $paspor->handling_fee == 0 ? 'background-color: #FFFF00;' : ''); ?>"><?php echo e($paspor->handling_fee ?? 0); ?></td>
                <td style="text-align: right; <?php echo e(empty($paspor->harga_materai) || $paspor->harga_materai == 0 ? 'background-color: #FFFF00;' : ''); ?>"><?php echo e($paspor->harga_materai ?? 0); ?></td>
                <td style="text-align: right; <?php echo e(empty($paspor->harga_surat_kuasa) || $paspor->harga_surat_kuasa == 0 ? 'background-color: #FFFF00;' : ''); ?>"><?php echo e($paspor->harga_surat_kuasa ?? 0); ?></td>
                <td style="text-align: right;">=G<?php echo e($row); ?>-(H<?php echo e($row); ?>+I<?php echo e($row); ?>+J<?php echo e($row); ?>+K<?php echo e($row); ?>+L<?php echo e($row); ?>)</td>
                <td style="text-align: right;">=0</td>
                <td style="text-align: right;">=M<?php echo e($row); ?>-N<?php echo e($row); ?></td>
                <td><?php echo e($paspor->tanggal_pengiriman_paspor ? $paspor->tanggal_pengiriman_paspor->format('d/m/Y') : ''); ?></td>
                <td><?php echo e($paspor->tanggal_paspor_diterima ? $paspor->tanggal_paspor_diterima->format('d/m/Y') : ''); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/paspor/exports/kompleks.blade.php ENDPATH**/ ?>