<?php $__env->startSection('title', 'Data Pengiriman Paspor'); ?>
<?php $__env->startSection('page-title', 'Data Pengiriman Paspor'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-5">

    
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 uppercase tracking-wide">Transaksi Hari Ini</p>
            <p class="text-3xl font-bold text-blue-700 mt-1"><?php echo e($statHariIni); ?></p>
        </div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 uppercase tracking-wide">Bulan Ini</p>
            <p class="text-3xl font-bold text-indigo-700 mt-1"><?php echo e($statBulanIni); ?></p>
        </div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 uppercase tracking-wide">Total Pemasukan Hari Ini</p>
            <p class="text-xl font-bold text-green-700 mt-1">Rp <?php echo e(number_format($omsetHariIni, 0, ',', '.')); ?></p>
        </div>
        <div class="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <p class="text-xs text-gray-500 uppercase tracking-wide">Total Filter (Grand)</p>
            <p class="text-xl font-bold text-orange-600 mt-1">Rp <?php echo e(number_format($summary->grand_total ?? 0, 0, ',', '.')); ?></p>
        </div>
    </div>

    
    <?php if($summary && $summary->total_pengiriman > 0 && request()->hasAny(['search','status','tanggal','tanggal_dari','tanggal_sampai','bulan','tahun'])): ?>
    <div class="bg-blue-50 border border-blue-200 rounded-xl px-5 py-4 grid grid-cols-2 gap-4 text-sm">
        <div>
            <p class="text-blue-500 text-xs">Total Pengiriman (Filter)</p>
            <p class="font-bold text-blue-800 text-lg"><?php echo e(number_format($summary->total_pengiriman)); ?></p>
        </div>
        <div>
            <p class="text-blue-500 text-xs">Grand Total Pembayaran</p>
            <p class="font-bold text-blue-900 text-lg">Rp <?php echo e(number_format($summary->grand_total, 0, ',', '.')); ?></p>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <a href="<?php echo e(route('paspor.create')); ?>"
           class="inline-flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
            Transaksi Baru
        </a>


    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
        <form method="GET" action="<?php echo e(route('paspor.index')); ?>" id="filterForm">
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">

                <div class="xl:col-span-2">
                    <label class="block text-xs font-medium text-gray-600 mb-1">Cari</label>
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                        placeholder="Cari nama penerima, ID transaksi, atau no. resi..."
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Status Pengiriman</label>
                    <select name="status" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">-- Semua Status --</option>
                        <?php $__currentLoopData = \App\Models\TransaksiPaspor::statusList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>" <?php echo e(request('status') == $s ? 'selected' : ''); ?>><?php echo e(ucfirst($s)); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Transaksi (dari)</label>
                    <input type="date" name="tanggal_dari" value="<?php echo e(request('tanggal_dari')); ?>"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tanggal Transaksi (sampai)</label>
                    <input type="date" name="tanggal_sampai" value="<?php echo e(request('tanggal_sampai')); ?>"
                        class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>

                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Bulan</label>
                    <select name="bulan" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">-- Bulan --</option>
                        <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($m); ?>" <?php echo e(request('bulan') == $m ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::create()->month($m)->translatedFormat('F')); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div>
                    <label class="block text-xs font-medium text-gray-600 mb-1">Tahun</label>
                    <select name="tahun" class="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">-- Tahun --</option>
                        <?php $__currentLoopData = range(now()->year, now()->year - 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($y); ?>" <?php echo e(request('tahun') == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="flex gap-2 mt-4">
                <button type="submit" class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-medium transition">
                    Terapkan Filter
                </button>
                <?php if(request()->hasAny(['search','status','tanggal','tanggal_dari','tanggal_sampai','bulan','tahun'])): ?>
                <a href="<?php echo e(route('paspor.index')); ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition">
                    Reset Filter
                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-4 py-3 text-left">Tgl Transaksi</th>
                        <th class="px-4 py-3 text-left">ID Transaksi & Struk</th>
                        <th class="px-4 py-3 text-left">Nama Penerima</th>
                        <th class="px-4 py-3 text-left">No. Resi</th>
                        <th class="px-4 py-3 text-center">Jml Paspor</th>
                        <th class="px-4 py-3 text-right">Total Pembayaran</th>
                        <th class="px-4 py-3 text-center">Status</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-4 py-3 whitespace-nowrap text-xs"><?php echo e($t->tanggal_transaksi?->format('d/m/Y')); ?></td>
                        <td class="px-4 py-3">
                            <div class="font-bold text-blue-700 whitespace-nowrap"><?php echo e($t->id_transaksi); ?></div>
                            <div class="text-xs text-gray-500">Struk: <?php echo e($t->no_struk); ?></div>
                        </td>
                        <td class="px-4 py-3 font-medium text-gray-800 whitespace-nowrap"><?php echo e($t->nama_penerima); ?></td>
                        <td class="px-4 py-3 font-mono text-xs text-gray-600 whitespace-nowrap"><?php echo e($t->no_resi ?? '-'); ?></td>
                        <td class="px-4 py-3 text-center font-bold text-gray-700"><?php echo e($t->jumlah_paspor); ?></td>
                        <td class="px-4 py-3 text-right font-semibold text-green-600 whitespace-nowrap">
                            Rp <?php echo e(number_format($t->total_pembayaran_pemohon, 0, ',', '.')); ?>

                        </td>

                        
                        <td class="px-4 py-3 text-center">
                            <form method="POST" action="<?php echo e(route('paspor.update-status', $t->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <select name="status_pengiriman" onchange="this.form.submit()"
                                    class="text-xs font-semibold px-2 py-1 rounded-full border-0 cursor-pointer
                                    <?php echo e($t->statusColorClass()); ?> focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    <?php $__currentLoopData = \App\Models\TransaksiPaspor::statusList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s); ?>" <?php echo e($t->status_pengiriman === $s ? 'selected' : ''); ?> class="bg-white text-gray-800">
                                        <?php echo e(ucfirst($s)); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                        </td>

                        <td class="px-4 py-3 text-center">
                            <div class="flex items-center justify-center gap-2">
                                <a href="<?php echo e(route('paspor.edit', $t->id)); ?>"
                                   class="text-blue-600 hover:text-blue-800 font-medium text-xs whitespace-nowrap">
                                    Detail/Edit
                                </a>
                                <span class="text-gray-300">|</span>
                                <a href="<?php echo e(route('paspor.print', $t->id)); ?>" target="_blank"
                                   class="text-green-600 hover:text-green-800 font-medium text-xs whitespace-nowrap">
                                    Struk
                                </a>
                                <?php if(auth()->user()->role === 'super_admin'): ?>
                                <form method="POST" action="<?php echo e(route('paspor.destroy', $t->id)); ?>" onsubmit="return confirm('Hapus data pengiriman ini? Data tidak dapat dikembalikan.')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-700 font-medium text-xs border-l border-gray-200 pl-2">Hapus</button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="px-4 py-12 text-center text-gray-400">
                            <svg class="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/>
                            </svg>
                            Tidak ada data yang cocok dengan filter
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>

                <?php if($transaksis->count() > 0): ?>
                <tfoot class="bg-gray-50 text-xs font-semibold text-gray-700 border-t-2 border-gray-200">
                    <tr>
                        <td colspan="5" class="px-4 py-3 text-right">
                            Total Halaman Ini:
                        </td>
                        <td class="px-4 py-3 text-right text-green-700">
                            Rp <?php echo e(number_format($transaksis->sum('total_pembayaran_pemohon'), 0, ',', '.')); ?>

                        </td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
                <?php endif; ?>
            </table>
        </div>

        <?php if($transaksis->hasPages()): ?>
        <div class="px-4 py-3 border-t border-gray-100">
            <?php echo e($transaksis->links()); ?>

        </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/paspor/index.blade.php ENDPATH**/ ?>