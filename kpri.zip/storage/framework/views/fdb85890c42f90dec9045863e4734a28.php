<table style="border: 1px solid #000;">
    <thead>
        <tr>
            <th style="font-weight: bold; text-align: center;">NO</th>
            <th style="font-weight: bold; text-align: center;">TANGGAL TRANSAKSI</th>
            <th style="font-weight: bold; text-align: center;">NO STRUK</th>
            <th style="font-weight: bold; text-align: center;">NAMA PENERIMA</th>
            <th style="font-weight: bold; text-align: center;">NO RESI</th>
            <th style="font-weight: bold; text-align: center;">JUMLAH PASPOR</th>
            <th style="font-weight: bold; text-align: center;">TOTAL PEMBAYARAN PEMOHON</th>
            <th style="font-weight: bold; text-align: center;">BIAYA KURIR (RESI)</th>
            <th style="font-weight: bold; text-align: center;">TANGGAL PENGIRIMAN PASPOR</th>
            <th style="font-weight: bold; text-align: center;">TANGGAL PASPOR DITERIMA</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $paspors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $paspor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: center;"><?php echo e($index + 1); ?></td>
                <td><?php echo e($paspor->tanggal_transaksi ? $paspor->tanggal_transaksi->format('d/m/Y') : ''); ?></td>
                <td style="text-align: center;"><?php echo e($paspor->no_struk); ?></td>
                <td><?php echo e($paspor->nama_penerima); ?></td>
                <td><?php echo e($paspor->no_resi); ?></td>
                <td style="text-align: center;"><?php echo e($paspor->jumlah_paspor); ?></td>
                <td style="text-align: right;"><?php echo e($paspor->total_pembayaran_pemohon); ?></td>
                <td style="text-align: right;"><?php echo e($paspor->biaya_kurir); ?></td>
                <td><?php echo e($paspor->tanggal_pengiriman_paspor ? $paspor->tanggal_pengiriman_paspor->format('d/m/Y') : ''); ?></td>
                <td><?php echo e($paspor->tanggal_paspor_diterima ? $paspor->tanggal_paspor_diterima->format('d/m/Y') : ''); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/paspor/exports/dasar.blade.php ENDPATH**/ ?>