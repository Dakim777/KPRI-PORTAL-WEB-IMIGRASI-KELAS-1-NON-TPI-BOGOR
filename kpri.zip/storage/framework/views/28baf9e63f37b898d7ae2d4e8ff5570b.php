<?php $__env->startSection('title', 'Riwayat Barang Masuk'); ?>
<?php $__env->startSection('page-title', 'Riwayat Pembelian & Barang Masuk'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <div class="flex items-center justify-between">
        <div>
            <h2 class="text-xl font-bold text-gray-800">Riwayat Pembelian</h2>
            <p class="text-sm text-gray-500 mt-1">Daftar transaksi barang masuk dari supplier.</p>
        </div>
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('kantin.pembelian.create')); ?>" class="bg-blue-700 hover:bg-blue-800 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition shadow-sm flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
                Input Barang Masuk
            </a>
            <a href="<?php echo e(route('kantin.laporan.pembelian.export')); ?>" class="bg-green-700 hover:bg-green-800 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition shadow-sm flex items-center gap-2">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                Export Excel
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
    <div class="p-4 bg-green-50 border border-green-200 text-green-800 rounded-xl text-sm flex items-start gap-2 shadow-sm">
        <svg class="w-5 h-5 text-green-500 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
        </svg>
        <span><?php echo e(session('success')); ?></span>
    </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50/80 text-gray-500 text-xs uppercase tracking-wider">
                    <tr>
                        <th class="px-6 py-4 text-left font-semibold">ID</th>
                        <th class="px-6 py-4 text-left font-semibold">Waktu Masuk</th>
                        <th class="px-6 py-4 text-left font-semibold">Petugas / Kasir</th>
                        <th class="px-6 py-4 text-left font-semibold">Rincian Barang</th>
                        <th class="px-6 py-4 text-right font-semibold">Total Nilai Beli</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php $__empty_1 = true; $__currentLoopData = $pembelians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50/50 transition">
                        <td class="px-6 py-4 font-mono text-gray-500 text-xs">#<?php echo e(str_pad($trx->id, 5, '0', STR_PAD_LEFT)); ?></td>
                        <td class="px-6 py-4 text-gray-600">
                            <span class="block text-gray-800 font-medium"><?php echo e($trx->created_at->format('d/m/Y')); ?></span>
                            <span class="text-xs"><?php echo e($trx->created_at->format('H:i')); ?></span>
                        </td>
                        <td class="px-6 py-4 text-gray-600"><?php echo e($trx->kasir->name ?? '—'); ?></td>
                        <td class="px-6 py-4">
                            <ul class="list-disc list-inside text-xs text-gray-600 space-y-1">
                                <?php $__currentLoopData = $trx->detailPembelians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <span class="font-medium text-gray-800"><?php echo e($detail->produkKantin->nama_produk ?? 'Produk Terhapus'); ?></span> 
                                    (<?php echo e($detail->qty); ?> pcs @ Rp <?php echo e(number_format($detail->harga_satuan, 0, ',', '.')); ?>)
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                        <td class="px-6 py-4 text-right font-semibold text-gray-800">
                            Rp <?php echo e(number_format($trx->total_pembelian, 0, ',', '.')); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-12 text-center text-gray-400">
                            <div class="flex flex-col items-center justify-center">
                                <svg class="w-12 h-12 mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"/>
                                </svg>
                                Belum ada data barang masuk.
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($pembelians->hasPages()): ?>
        <div class="px-6 py-4 border-t border-gray-100 bg-gray-50/50">
            <?php echo e($pembelians->links()); ?>

        </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/kantin/pembelian/index.blade.php ENDPATH**/ ?>