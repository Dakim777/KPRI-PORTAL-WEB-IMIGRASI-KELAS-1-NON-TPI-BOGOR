<?php $__env->startSection('title', 'Input Data Pengiriman Paspor'); ?>
<?php $__env->startSection('page-title', 'Input Pengiriman Paspor Baru'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100">
            <h3 class="font-semibold text-gray-800">Form Data Pengiriman Paspor (Transaksi Baru)</h3>
            <p class="text-xs text-gray-400 mt-0.5">Semua field bertanda <span class="text-red-500">*</span> wajib diisi.</p>
        </div>

        <form method="POST" action="<?php echo e(route('paspor.store')); ?>" class="px-6 py-6 space-y-5">
            <?php echo csrf_field(); ?>

            
            <div>
                <label for="nama_penerima" class="block text-sm font-medium text-gray-700 mb-1.5">
                    Nama Penerima (Pemohon Transaksi) <span class="text-red-500">*</span>
                </label>
                <input type="text" id="nama_penerima" name="nama_penerima"
                    value="<?php echo e(old('nama_penerima')); ?>" required
                    placeholder="Nama lengkap pemohon atau wakil keluarga"
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['nama_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                <?php $__errorArgs = ['nama_penerima'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label for="tanggal_transaksi" class="block text-sm font-medium text-gray-700 mb-1.5">
                    Tanggal Transaksi <span class="text-red-500">*</span>
                </label>
                <input type="date" id="tanggal_transaksi" name="tanggal_transaksi"
                    value="<?php echo e(old('tanggal_transaksi', date('Y-m-d'))); ?>" required
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['tanggal_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                <?php $__errorArgs = ['tanggal_transaksi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <label for="jumlah_paspor" class="block text-sm font-medium text-gray-700 mb-1.5">
                    Jumlah Paspor <span class="text-red-500">*</span>
                </label>
                <input type="number" id="jumlah_paspor" name="jumlah_paspor"
                    value="<?php echo e(old('jumlah_paspor')); ?>" required min="1"
                    placeholder="Contoh: 4"
                    class="w-full lg:w-1/3 px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['jumlah_paspor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                <?php $__errorArgs = ['jumlah_paspor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <div id="nama-paspor-container" class="mt-4 space-y-3">
                    
                </div>
            </div>

            
            <div>
                <label for="alamat_tujuan_pengiriman" class="block text-sm font-medium text-gray-700 mb-1.5">
                    Alamat Tujuan Pengiriman <span class="text-red-500">*</span>
                </label>
                <textarea id="alamat_tujuan_pengiriman" name="alamat_tujuan_pengiriman" rows="3" required
                    placeholder="Alamat lengkap tujuan pengiriman..."
                    class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none <?php $__errorArgs = ['alamat_tujuan_pengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('alamat_tujuan_pengiriman')); ?></textarea>
                <?php $__errorArgs = ['alamat_tujuan_pengiriman'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="mt-1 text-xs text-red-600"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label for="no_hp" class="block text-sm font-medium text-gray-700 mb-1.5">No. HP (Opsional)</label>
                    <input type="text" id="no_hp" name="no_hp" value="<?php echo e(old('no_hp')); ?>" placeholder="08..."
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                </div>
                <div>
                    <label for="metode_pembayaran" class="block text-sm font-medium text-gray-700 mb-1.5">Metode Pembayaran (Opsional)</label>
                    <select id="metode_pembayaran" name="metode_pembayaran" class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">-- Pilih Metode --</option>
                        <option value="Cash" <?php echo e(old('metode_pembayaran') == 'Cash' ? 'selected' : ''); ?>>Cash</option>
                        <option value="Transfer" <?php echo e(old('metode_pembayaran') == 'Transfer' ? 'selected' : ''); ?>>Transfer</option>
                        <option value="QRIS" <?php echo e(old('metode_pembayaran') == 'QRIS' ? 'selected' : ''); ?>>QRIS</option>
                    </select>
                </div>
            </div>

            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label for="estimasi_tanggal_selesai" class="block text-sm font-medium text-gray-700 mb-1.5">Estimasi Tanggal Selesai (Opsional)</label>
                    <input type="date" id="estimasi_tanggal_selesai" name="estimasi_tanggal_selesai" value="<?php echo e(old('estimasi_tanggal_selesai')); ?>"
                        class="w-full px-4 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 <?php $__errorArgs = ['estimasi_tanggal_selesai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-400 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                </div>
            </div>

            
            <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 class="text-sm font-semibold text-blue-800 mb-4 border-b border-blue-200 pb-2">Rincian Harga (Opsional di awal transaksi)</h4>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label for="biaya_kurir" class="block text-xs font-semibold text-blue-800 uppercase mb-1.5">Layanan Kurir (Rp)</label>
                        <input type="number" id="biaya_kurir" name="biaya_kurir" value="<?php echo e(old('biaya_kurir', 0)); ?>" min="0"
                            class="harga-input w-full px-3.5 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="biaya_modal_packaging" class="block text-xs font-semibold text-blue-800 uppercase mb-1.5">Safe Packaging (Rp)</label>
                        <input type="number" id="biaya_modal_packaging" name="biaya_modal_packaging" value="<?php echo e(old('biaya_modal_packaging', 1000)); ?>" min="0"
                            class="harga-input w-full px-3.5 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label for="handling_fee" class="block text-xs font-semibold text-blue-800 uppercase mb-1.5">Handling Fee (Rp)</label>
                        <input type="number" id="handling_fee" name="handling_fee" value="<?php echo e(old('handling_fee', 0)); ?>" min="0"
                            class="harga-input w-full px-3.5 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                        <label for="harga_materai" class="block text-xs font-semibold text-blue-800 uppercase mb-1.5">Biaya Materai (Rp)</label>
                        <input type="number" id="harga_materai" name="harga_materai" value="<?php echo e(old('harga_materai', 0)); ?>" min="0"
                            class="harga-input w-full px-3.5 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label for="harga_surat_kuasa" class="block text-xs font-semibold text-blue-800 uppercase mb-1.5">Biaya Surat Kuasa (Rp)</label>
                        <input type="number" id="harga_surat_kuasa" name="harga_surat_kuasa" value="<?php echo e(old('harga_surat_kuasa', 0)); ?>" min="0"
                            class="harga-input w-full px-3.5 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                
                <div class="mt-4 pt-4 border-t border-blue-200">
                    <label for="total_pembayaran_pemohon" class="block text-sm font-semibold text-blue-900 mb-1.5">
                        Total Pembayaran Pemohon (Bisa diedit)
                    </label>
                    <input type="number" id="total_pembayaran_pemohon" name="total_pembayaran_pemohon"
                        value="<?php echo e(old('total_pembayaran_pemohon')); ?>" min="0"
                        class="w-full px-4 py-2.5 border border-blue-300 rounded-lg text-sm font-bold text-green-700 bg-white focus:outline-none focus:ring-2 focus:ring-green-500" />
                </div>
            </div>

            
            <div class="flex items-center gap-3 pt-2 border-t border-gray-100">
                <button type="submit"
                    class="bg-blue-700 hover:bg-blue-800 text-white px-6 py-2.5 rounded-lg text-sm font-semibold transition focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2">
                    Simpan Data
                </button>
                <a href="<?php echo e(route('paspor.index')); ?>"
                   class="text-sm text-gray-500 hover:text-gray-700 px-4 py-2.5 rounded-lg border border-gray-300 hover:bg-gray-50 transition">
                    Batal
                </a>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const jumlahInput = document.getElementById('jumlah_paspor');
    const container = document.getElementById('nama-paspor-container');
    const biayaKurir = document.getElementById('biaya_kurir');
    const biayaPackaging = document.getElementById('biaya_modal_packaging');
    const handlingFee = document.getElementById('handling_fee');
    const totalPembayaran = document.getElementById('total_pembayaran_pemohon');
    const hargaMaterai = document.getElementById('harga_materai');
    const hargaSuratKuasa = document.getElementById('harga_surat_kuasa');
    
    // Track if user manually changed total
    let totalManuallyEdited = false;
    let materaiEdited = false;
    let skEdited = false;

    totalPembayaran.addEventListener('input', () => { totalManuallyEdited = true; });
    hargaMaterai.addEventListener('input', () => { materaiEdited = true; hitungTotal(); });
    hargaSuratKuasa.addEventListener('input', () => { skEdited = true; hitungTotal(); });

    function hitungTotal() {
        let count = parseInt(jumlahInput.value) || 0;
        
        if (!materaiEdited) {
            hargaMaterai.value = count * 12000;
        }
        if (!skEdited) {
            hargaSuratKuasa.value = count * 1000;
        }

        if (!totalManuallyEdited) {
            let kurir = parseFloat(biayaKurir.value) || 0;
            let pack = parseFloat(biayaPackaging.value) || 0;
            let fee = parseFloat(handlingFee.value) || 0;
            let materai = parseFloat(hargaMaterai.value) || 0;
            let sk = parseFloat(hargaSuratKuasa.value) || 0;
            
            let finalTotal = kurir + pack + fee + materai + sk;
            totalPembayaran.value = finalTotal;
        }
    }

    function renderNamaInputs() {
        let count = parseInt(jumlahInput.value) || 0;
        
        // Cache existing values
        let existingInputs = container.querySelectorAll('input[type="text"]');
        let values = Array.from(existingInputs).map(inp => inp.value);
        
        container.innerHTML = '';
        if (count > 0) {
            container.innerHTML = `<p class="text-xs font-semibold text-blue-700 mb-2">Silakan isi rincian ${count} nama pemilik paspor:</p>`;
            for(let i=1; i<=count; i++) {
                let val = values[i-1] !== undefined ? values[i-1] : '';
                container.innerHTML += `
                    <div class="mb-2 flex items-center gap-3">
                        <span class="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold shrink-0">${i}</span>
                        <input type="text" name="nama_paspor_list[]" value="${val}" required placeholder="Nama di paspor ke-${i}" class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    </div>
                `;
            }
        }
        
        hitungTotal();
    }

    jumlahInput.addEventListener('input', renderNamaInputs);
    document.querySelectorAll('.harga-input').forEach(el => {
        el.addEventListener('input', function() {
            totalManuallyEdited = false; // Reset flag when other prices change
            hitungTotal();
        });
    });

    // Render on load if old value exists
    if(jumlahInput.value) {
        renderNamaInputs();
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/paspor/create.blade.php ENDPATH**/ ?>