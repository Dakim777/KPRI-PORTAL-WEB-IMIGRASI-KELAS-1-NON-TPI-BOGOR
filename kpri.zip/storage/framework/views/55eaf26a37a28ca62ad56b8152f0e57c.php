<?php $__env->startSection('title', 'Detail Pengiriman Paspor #' . $paspor->id_transaksi); ?>
<?php $__env->startSection('page-title', 'Detail Pengiriman Paspor'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-3xl space-y-4">

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">

        
        <div class="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <div>
                <h3 class="font-semibold text-gray-800 text-lg">
                    <?php echo e($paspor->id_transaksi); ?>

                </h3>
                <p class="text-xs text-gray-400 mt-0.5">No. Struk: <?php echo e($paspor->no_struk); ?> · Dibuat: <?php echo e($paspor->created_at->format('d F Y, H:i:s')); ?></p>
            </div>
            <span class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold <?php echo e($paspor->statusColorClass()); ?>">
                <?php echo e(ucfirst($paspor->status_pengiriman)); ?>

            </span>
        </div>

        
        <div class="px-6 py-5">
            <div class="grid grid-cols-2 md:grid-cols-3 gap-x-8 gap-y-5 text-sm">

                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Nama Penerima</p>
                    <p class="font-semibold text-gray-800"><?php echo e($paspor->nama_penerima); ?></p>
                </div>

                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Jumlah Paspor</p>
                    <p class="font-mono font-bold text-blue-700"><?php echo e($paspor->jumlah_paspor); ?> Paspor</p>
                </div>
                
                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">No. Resi</p>
                    <p class="font-mono font-semibold text-gray-800"><?php echo e($paspor->no_resi ?? 'Belum ada'); ?></p>
                </div>

                <div class="col-span-2 md:col-span-3">
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Daftar Nama Pemilik Paspor</p>
                    <div class="flex flex-wrap gap-2 mt-1">
                        <?php 
                            $list = is_array($paspor->nama_paspor_list) ? $paspor->nama_paspor_list : json_decode($paspor->nama_paspor_list, true) ?? [];
                        ?>
                        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-md bg-gray-100 text-gray-700 text-xs font-medium border border-gray-200">
                                <?php echo e($nama); ?>

                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="col-span-2 md:col-span-3">
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Alamat Tujuan Pengiriman</p>
                    <p class="font-semibold text-gray-800 leading-snug"><?php echo e($paspor->alamat_tujuan_pengiriman); ?></p>
                </div>

                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Tgl Transaksi</p>
                    <p class="font-semibold text-gray-800"><?php echo e($paspor->tanggal_transaksi?->format('d M Y')); ?></p>
                </div>

                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Tgl Kirim Paspor</p>
                    <p class="font-semibold text-gray-800"><?php echo e($paspor->tanggal_pengiriman_paspor?->format('d M Y') ?? '-'); ?></p>
                </div>

                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Tgl Paspor Diterima</p>
                    <p class="font-semibold text-gray-800"><?php echo e($paspor->tanggal_paspor_diterima?->format('d M Y') ?? '-'); ?></p>
                </div>

                <div>
                    <p class="text-gray-400 text-xs uppercase tracking-wide mb-0.5">Input oleh (Kasir)</p>
                    <p class="font-semibold text-gray-800"><?php echo e($paspor->kasir->name ?? '—'); ?></p>
                </div>
            </div>

            <hr class="my-5 border-dashed border-gray-200" />

            
            <div class="space-y-2 text-sm">
                <div class="flex justify-between">
                    <span class="text-gray-500">Biaya Kurir / Resi</span>
                    <span class="font-medium text-gray-700">Rp <?php echo e(number_format($paspor->biaya_kurir, 0, ',', '.')); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Harga Modal Packaging</span>
                    <span class="font-medium text-gray-700">Rp <?php echo e(number_format($paspor->biaya_modal_packaging, 0, ',', '.')); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Handling Fee</span>
                    <span class="font-medium text-gray-700">Rp <?php echo e(number_format($paspor->handling_fee, 0, ',', '.')); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Harga Materai (Auto <?php echo e($paspor->jumlah_paspor); ?> x Rp 12.000)</span>
                    <span class="font-medium text-gray-700">Rp <?php echo e(number_format($paspor->harga_materai, 0, ',', '.')); ?></span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-500">Harga Surat Kuasa (Auto <?php echo e($paspor->jumlah_paspor); ?> x Rp 1.000)</span>
                    <span class="font-medium text-gray-700">Rp <?php echo e(number_format($paspor->harga_surat_kuasa, 0, ',', '.')); ?></span>
                </div>
                
                <div class="flex justify-between pt-3 border-t border-gray-100 text-base font-bold">
                    <span class="text-gray-800">Total Pembayaran Pemohon</span>
                    <span class="text-green-700 text-lg">Rp <?php echo e(number_format($paspor->total_pembayaran_pemohon, 0, ',', '.')); ?></span>
                </div>
                
                <?php 
                    $pendapatan = $paspor->total_pembayaran_pemohon - ($paspor->biaya_kurir + $paspor->biaya_modal_packaging + $paspor->harga_materai + $paspor->harga_surat_kuasa);
                ?>
                <div class="flex justify-between pt-1">
                    <span class="text-gray-500 font-semibold italic">Estimasi Pendapatan (Laba)</span>
                    <span class="text-blue-700 font-bold italic">Rp <?php echo e(number_format($pendapatan, 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 px-6 py-5">
        <h4 class="text-sm font-semibold text-gray-700 mb-4">Update Status Pengiriman</h4>
        <form method="POST" action="<?php echo e(route('paspor.update-status', $paspor->id)); ?>" id="formUpdateStatus">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            
            <div class="flex items-center gap-3 mb-4">
                <select name="status_pengiriman" id="statusSelect"
                    onchange="toggleBiayaFields(this.value)"
                    class="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <?php $__currentLoopData = \App\Models\TransaksiPaspor::statusList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>" <?php echo e($paspor->status_pengiriman === $s ? 'selected' : ''); ?> class="bg-white text-gray-800">
                            <?php echo e(ucfirst($s)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <button type="submit"
                    class="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition whitespace-nowrap">
                    Simpan
                </button>
            </div>

            
            <div id="biayaFields" class="border-t border-gray-100 pt-4 space-y-3">
                <p class="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Sesuaikan Biaya (opsional)</p>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Biaya Kurir (Rp)</label>
                        <input type="number" name="biaya_kurir" min="0" step="500"
                            value="<?php echo e(old('biaya_kurir', $paspor->biaya_kurir)); ?>"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="0" />
                    </div>
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Biaya Modal Packaging (Rp)</label>
                        <input type="number" name="biaya_modal_packaging" min="0" step="500"
                            value="<?php echo e(old('biaya_modal_packaging', $paspor->biaya_modal_packaging)); ?>"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="0" />
                    </div>
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Harga Materai (Rp)</label>
                        <input type="number" name="harga_materai" min="0" step="1000"
                            value="<?php echo e(old('harga_materai', $paspor->harga_materai)); ?>"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="0" />
                    </div>
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Harga Surat Kuasa (Rp)</label>
                        <input type="number" name="harga_surat_kuasa" min="0" step="500"
                            value="<?php echo e(old('harga_surat_kuasa', $paspor->harga_surat_kuasa)); ?>"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="0" />
                    </div>
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">Handling Fee (Rp)</label>
                        <input type="number" name="handling_fee" min="0" step="500"
                            value="<?php echo e(old('handling_fee', $paspor->handling_fee)); ?>"
                            class="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="0" />
                    </div>
                    <div>
                        <label class="block text-xs text-gray-500 mb-1">No. Resi Pengiriman</label>
                        <div class="flex items-center gap-2">
                            <input type="text" id="no_resi_show" name="no_resi"
                                value="<?php echo e(old('no_resi', $paspor->no_resi)); ?>"
                                class="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Scan atau ketik nomor resi..." />
                            <?php if (isset($component)) { $__componentOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.barcode-scanner','data' => ['targetId' => 'no_resi_show']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('barcode-scanner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['targetId' => 'no_resi_show']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf)): ?>
<?php $attributes = $__attributesOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf; ?>
<?php unset($__attributesOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf)): ?>
<?php $component = $__componentOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf; ?>
<?php unset($__componentOriginal9dd6d12390a68f9f1ca2bdbf2f7374bf); ?>
<?php endif; ?>
                        </div>
                    </div>
                </div>

                
                <div class="bg-green-50 border-2 border-green-300 rounded-xl p-4 mt-3">
                    <label class="block text-sm font-bold text-green-800 mb-2">Total Pembayaran Pemohon (Rp) — <span class="font-normal text-green-700">bisa diedit bebas</span></label>
                    <input type="number" name="total_pembayaran_pemohon" min="0" step="500"
                        value="<?php echo e(old('total_pembayaran_pemohon', $paspor->total_pembayaran_pemohon)); ?>"
                        class="w-full px-4 py-3 border-2 border-green-400 rounded-lg text-lg font-bold text-green-900 focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
                        placeholder="0" />
                    <p class="text-xs text-green-600 mt-1">Sesuaikan nominal ini sesuai kesepakatan dengan pemohon. Nilai ini yang akan tampil di Struk.</p>
                </div>
            </div>
        </form>
    </div>

    <script>
        function toggleBiayaFields(val) {
            // Always visible now, but we can highlight when status is diproses
            const fields = document.getElementById('biayaFields');
            if (val === 'diproses' || val === 'selesai') {
                fields.style.display = 'block';
            } else {
                fields.style.display = 'block';
            }
        }
    </script>

    <div class="flex gap-3 flex-wrap items-center justify-between">
        <div class="flex gap-3">
            <a href="<?php echo e(route('paspor.index')); ?>"
               class="inline-flex items-center gap-2 bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
                Kembali ke Daftar
            </a>
            <a href="<?php echo e(route('paspor.create')); ?>"
               class="inline-flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
                Input Baru
            </a>
            <a href="<?php echo e(route('paspor.edit', $paspor->id)); ?>"
               class="inline-flex items-center gap-2 bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"/></svg>
                Edit Data
            </a>
            <a href="<?php echo e(route('paspor.print', $paspor->id)); ?>" target="_blank"
               class="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg>
                Cetak Struk
            </a>
        </div>
        
        <?php if(auth()->user()->role === 'super_admin'): ?>
        <form method="POST" action="<?php echo e(route('paspor.destroy', $paspor->id)); ?>" onsubmit="return confirm('Hapus riwayat pengiriman ini? Data akan dipindahkan ke Tong Sampah.')">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="inline-flex items-center gap-2 bg-red-100 text-red-600 hover:bg-red-200 px-4 py-2 rounded-lg text-sm font-semibold transition">
                Hapus Data
            </button>
        </form>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/paspor/show.blade.php ENDPATH**/ ?>