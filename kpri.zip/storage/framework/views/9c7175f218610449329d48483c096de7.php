<?php $__env->startSection('title', 'Log Aktivitas Sistem'); ?>
<?php $__env->startSection('page-title', 'Audit Trail (Log Aktivitas)'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-5">
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
            <h3 class="font-semibold text-gray-800">Daftar Aktivitas Pengguna</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-4 py-3 text-left">Waktu</th>
                        <th class="px-4 py-3 text-left">Pengguna</th>
                        <th class="px-4 py-3 text-left">Aksi</th>
                        <th class="px-4 py-3 text-left">Target (Model)</th>
                        <th class="px-4 py-3 text-left">Detail Perubahan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 text-xs text-gray-500 whitespace-nowrap"><?php echo e($log->created_at->format('d/m/Y H:i:s')); ?></td>
                        <td class="px-4 py-3 font-medium"><?php echo e($log->causer ? $log->causer->name : 'Sistem'); ?></td>
                        <td class="px-4 py-3">
                            <?php
                                $color = match($log->description) {
                                    'created' => 'bg-green-100 text-green-700',
                                    'updated' => 'bg-blue-100 text-blue-700',
                                    'deleted' => 'bg-red-100 text-red-700',
                                    default => 'bg-gray-100 text-gray-700',
                                };
                            ?>
                            <span class="inline-flex px-2 py-0.5 rounded-full text-xs font-semibold uppercase <?php echo e($color); ?>">
                                <?php echo e($log->description); ?>

                            </span>
                        </td>
                        <td class="px-4 py-3 text-xs text-gray-600 font-mono">
                            <?php echo e(class_basename($log->subject_type)); ?> #<?php echo e($log->subject_id); ?>

                        </td>
                        <td class="px-4 py-3 text-xs text-gray-500">
                            <?php if($log->properties && $log->properties->count() > 0): ?>
                                <details class="cursor-pointer">
                                    <summary class="text-blue-600 hover:underline">Lihat Detail</summary>
                                    <pre class="mt-2 p-2 bg-gray-100 rounded text-[10px] overflow-x-auto"><?php echo e(json_encode($log->properties, JSON_PRETTY_PRINT)); ?></pre>
                                </details>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-4 py-8 text-center text-gray-400">Belum ada log aktivitas.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php if($logs->hasPages()): ?>
        <div class="px-4 py-3 border-t border-gray-100"><?php echo e($logs->links()); ?></div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/admin/logs.blade.php ENDPATH**/ ?>