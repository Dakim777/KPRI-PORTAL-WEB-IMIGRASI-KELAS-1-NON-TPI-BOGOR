<?php $__env->startSection('title', 'Tong Sampah'); ?>
<?php $__env->startSection('page-title', 'Tong Sampah (Arsip Terhapus)'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-8">
    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 bg-red-50 flex items-center gap-2">
            <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            <h3 class="font-semibold text-red-800">Transaksi Paspor Terhapus</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-4 py-3 text-left">Resi & Pemohon</th>
                        <th class="px-4 py-3 text-left">Dihapus Pada</th>
                        <th class="px-4 py-3 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $trashedPaspor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3">
                            <p class="font-medium text-gray-800"><?php echo e($p->nama_penerima); ?></p>
                            <p class="text-xs text-gray-500 font-mono"><?php echo e($p->no_resi); ?></p>
                        </td>
                        <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($p->deleted_at->format('d/m/Y H:i')); ?></td>
                        <td class="px-4 py-3 flex gap-2">
                            <form method="POST" action="<?php echo e(route('admin.trash.restore-paspor', $p->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="px-3 py-1.5 bg-green-100 text-green-700 hover:bg-green-200 rounded text-xs font-semibold">Restore</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.trash.force-paspor', $p->id)); ?>" onsubmit="return confirm('Hapus permanen?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded text-xs font-semibold">Hapus Permanen</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="px-4 py-6 text-center text-gray-400">Tong sampah kosong</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 bg-red-50 flex items-center gap-2">
            <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            <h3 class="font-semibold text-red-800">Produk Kantin Terhapus</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-4 py-3 text-left">Produk</th>
                        <th class="px-4 py-3 text-left">Dihapus Pada</th>
                        <th class="px-4 py-3 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $trashedProduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 font-medium"><?php echo e($p->nama_produk); ?></td>
                        <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($p->deleted_at->format('d/m/Y H:i')); ?></td>
                        <td class="px-4 py-3 flex gap-2">
                            <form method="POST" action="<?php echo e(route('admin.trash.restore-produk', $p->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="px-3 py-1.5 bg-green-100 text-green-700 hover:bg-green-200 rounded text-xs font-semibold">Restore</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.trash.force-produk', $p->id)); ?>" onsubmit="return confirm('Hapus permanen?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded text-xs font-semibold">Hapus Permanen</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="px-4 py-6 text-center text-gray-400">Tong sampah kosong</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    
    
    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div class="px-6 py-4 border-b border-gray-100 bg-red-50 flex items-center gap-2">
            <svg class="w-5 h-5 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
            <h3 class="font-semibold text-red-800">Transaksi Kantin Terhapus</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 text-gray-500 text-xs uppercase">
                    <tr>
                        <th class="px-4 py-3 text-left">Total Harga</th>
                        <th class="px-4 py-3 text-left">Kasir</th>
                        <th class="px-4 py-3 text-left">Dihapus Pada</th>
                        <th class="px-4 py-3 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    <?php $__empty_1 = true; $__currentLoopData = $trashedTransaksiKantin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3 font-medium">Rp <?php echo e(number_format($t->total_harga, 0, ',', '.')); ?></td>
                        <td class="px-4 py-3 text-xs"><?php echo e($t->kasir->name ?? '-'); ?></td>
                        <td class="px-4 py-3 text-xs text-gray-500"><?php echo e($t->deleted_at->format('d/m/Y H:i')); ?></td>
                        <td class="px-4 py-3 flex gap-2">
                            <form method="POST" action="<?php echo e(route('admin.trash.restore-transaksi-kantin', $t->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="px-3 py-1.5 bg-green-100 text-green-700 hover:bg-green-200 rounded text-xs font-semibold">Restore</button>
                            </form>
                            <form method="POST" action="<?php echo e(route('admin.trash.force-transaksi-kantin', $t->id)); ?>" onsubmit="return confirm('Hapus permanen?')">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button class="px-3 py-1.5 bg-red-100 text-red-700 hover:bg-red-200 rounded text-xs font-semibold">Hapus Permanen</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="px-4 py-6 text-center text-gray-400">Tong sampah kosong</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/admin/trash.blade.php ENDPATH**/ ?>