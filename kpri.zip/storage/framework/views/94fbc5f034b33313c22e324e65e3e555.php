<table>
    <tr>
        <td colspan="8">REKAPITULASI PENDAPATAN GLOBAL KANTIN</td>
    </tr>
    <tr>
        <td colspan="8">PERIODE: <?php echo e(count($laporanData) > 0 ? strtoupper($laporanData[0]['tanggal']) : 'SEMUA WAKTU'); ?></td>
    </tr>
    <tr>
        <td colspan="8"></td>
    </tr>
    <tr>
        <th>NO</th>
        <th>NAMA PRODUK</th>
        <th>TERJUAL (QTY)</th>
        <th>TOTAL OMSET (PENJUALAN KOTOR)</th>
        <th>TOTAL MODAL (HPP)</th>
        <th>LABA KOTOR</th>
        <th>PENDAPATAN KOPERASI (70%)</th>
        <th>BAGIAN BU AJAT (30%)</th>
    </tr>

    <?php 
        $no = 1;
        $currentRow = 5; // Data starts at row 5
    ?>

    <?php $__currentLoopData = $laporanData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $qty = $data['keluar'];
            $omset = $qty * $data['harga_jual'];
            $modal = ($data['qty_hpp_lama'] * $data['hpp_lama']) + ($data['qty_hpp_baru'] * $data['hpp_baru']);
        ?>
        <tr>
            <td><?php echo e($no++); ?></td>
            <td><?php echo e($data['nama_produk']); ?></td>
            <td><?php echo e($qty); ?></td>
            <td><?php echo e($omset); ?></td>
            <td><?php echo e($modal); ?></td>
            
            <!-- LABA KOTOR: D - E -->
            <td>=D<?php echo e($currentRow); ?>-E<?php echo e($currentRow); ?></td>
            
            <!-- KOPERASI 70%: F * 0.7 -->
            <td>=F<?php echo e($currentRow); ?>*0.7</td>
            
            <!-- BU AJAT 30%: F * 0.3 -->
            <td>=F<?php echo e($currentRow); ?>*0.3</td>
        </tr>
        <?php $currentRow++; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php 
        $lastDataRow = $currentRow - 1; 
        $totalRow = $currentRow; 
    ?>

    <tr>
        <td colspan="2" style="text-align: right;">TOTAL KESELURUHAN:</td>
        <td>=SUM(C4:C<?php echo e($lastDataRow); ?>)</td>
        <td>=SUM(D4:D<?php echo e($lastDataRow); ?>)</td>
        <td>=SUM(E4:E<?php echo e($lastDataRow); ?>)</td>
        <td>=SUM(F4:F<?php echo e($lastDataRow); ?>)</td>
        <td>=SUM(G4:G<?php echo e($lastDataRow); ?>)</td>
        <td>=SUM(H4:H<?php echo e($lastDataRow); ?>)</td>
    </tr>
</table>
<?php /**PATH /Users/dakim/Herd/portal-koperasi/resources/views/kantin/excel/laporan_penjualan_global.blade.php ENDPATH**/ ?>